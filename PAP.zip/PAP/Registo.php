<!DOCTYPE html>
<html>
<title>GamersList</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<head>
	<title>GamersList/Registo</title>
	<link rel="stylesheet" href="estilos.css">
</head>
<body>
<div class="formrespon formback2 col-12 col-s-12" >
		<center><form method="POST" action="Registar.php">
			<label class="form-titulo"><b><u>Re</u>g<u>isto</u></b></label><br><br>	
			
			<div class="input-icons">
			<i class="material-icons iconz">&#xe7fd;</i>
			<input class="nome-form" style="text-align:center;" type="text" name="nome" required placeholder="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nome de Utilizador">
			<br>
			</br>
</div>
<div class="input-icons">
			<i class="material-icons iconz">&#xe158;</i>
			<input class="nome-form" type="text" style="text-align:center;" name="email" placeholder="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Email" required>
			<br>
			</br>
</div>
<div class="input-icons">
			<i class="material-icons iconz">&#xe897;</i>
			<input  class="nome-form" type="password" style="text-align:center;" name="password" placeholder="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Palavra-Passe" required>
			<br>
			</br>
</div>
<div class="input-icons">
			<i class="material-icons iconz">&#xe897;</i>
			<input  class="nome-form" type="password" style="text-align:center;" name="confirmar" placeholder="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Confirme a sua Palavra-Passe" required>
			<br>
			</br>
</div>
			<a class="button2" href="Login.php">Voltar</a>
			<input class="button2" type="submit" name="submit" value="Registar"><br/>
		</form></center>
	</div>
	
</body>
</html> 	