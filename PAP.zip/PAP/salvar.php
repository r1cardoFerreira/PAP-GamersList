<?php
$ID = filter_input(INPUT_POST, 'ID');
$novonome_jogo = filter_input(INPUT_POST, 'nome_jogo');
$novaempresa = filter_input(INPUT_POST, 'empresa');
$novadata_estreia = filter_input(INPUT_POST, 'data_estreia');
$novadesc_jogo = filter_input(INPUT_POST, 'desc_jogo');
$novacategoria1 = filter_input(INPUT_POST, 'categoria1');
$novacategoria2 = filter_input(INPUT_POST, 'categoria2');
$novacategoria3 = filter_input(INPUT_POST, 'categoria3');



$ligacao = mysqli_connect("localhost","ricardo","123","gamerslist");
mysqli_set_charset($ligacao,"utf8");//resolve a questão dos acentos 
	if (!$ligacao) {
		header("Location:exibir.php?alteracao=false");
		exit;
	}
	//Update á tabela
	$sql = "UPDATE jogos SET nome_jogo='".$novonome_jogo."',empresa='".$novaempresa."',data_estreia='".$novadata_estreia."',desc_jogo='".$novadesc_jogo."',categoria1='".$novacategoria1."'
	,categoria2='".$novacategoria2."',categoria3='".$novacategoria3."' WHERE ID='".$ID."'";
	$update = mysqli_query($ligacao,$sql);
	//se der certo
	if (!$update) {		
		header("Location:exibir.php?alter=false");
		exit;
	}
	header("Location:editarjogos.php?alter=true");
?>