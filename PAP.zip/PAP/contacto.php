<?php
require_once 'navbar.php';
require_once 'footer.php';