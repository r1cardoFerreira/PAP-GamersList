<?php
$ligacao = mysqli_connect("localhost","ricardo","123","gamerslist");
mysqli_set_charset($ligacao,"utf8");//resolve a questão dos acentos 
$jogo = filter_input(INPUT_POST, 'jogos');
session_start();
$nome = $_SESSION['nome'];
$delete = "DELETE FROM listas WHERE Utilizador = '$nome' AND jogos ='$jogo'";


if(isset($_POST['submit'])){
$result=mysqli_query($ligacao,$delete);
exit;         
  }?>