<?php
require_once 'navbar.php';
?>
<div class="col-12 pd">
        <center><form action="Notícias.php " method="get">
            <input class="barra-pesquisa" type="text" name="pesquisa" autocomplete="off" placeholder="Pesquisa" value=""></div>
            </form></center>
     </div>
     <hr>  
            </div>
            <?php
           	//Estableça a ligação com o mysql ALTERNATIVA AO LOGIN COM INCLUDE
			$ligacao = mysqli_connect("localhost","ricardo","123","gamerslist");
			mysqli_set_charset($ligacao,"utf8");//resolve a questão dos acentos 
			if (!$ligacao) {
				echo "Pesquisa indefenida";
				exit;
			}
            $pesquisa ="";
            if(!empty($_GET['pesquisa'])){  
                $pesquisa = $_GET['pesquisa'];
            }
            
            if($pesquisa != ""){
                $sql ="SELECT * FROM noticias Where titulo LIKE '%$pesquisa%' OR tags LIKE '%$pesquisa%' OR ano LIKE '%$pesquisa%'";
            }
            if($pesquisa == "" || $pesquisa == null){
                  $sql = "SELECT * FROM notícias";
              }
              $consulta = mysqli_query($ligacao,$sql);
              if (!$consulta) {
                    echo "Erro ao realizar a consulta.";
                    exit;
              }
              while ($dados = mysqli_fetch_assoc($consulta)) {
                    
                 echo "<div class='col-12 col-s-12 respons tam background-noticias'>";
                 echo "<h2 class='gamesname'><b>".$dados["titulo"]."</b></h2>";
                 echo "<img class='Noticiaimg' src=".$dados['img']."><br><br>";   
                 echo "<span class='empresa respons'><u>Tags:</u>".$dados["tags"]."</span><br><br>";      
                 echo "<span class='noticiasdesc respons'>".$dados["Desc_not"]."</span><br><br>"  ;    
                 echo "</div>";
                 echo "</div>";
                    
                  }