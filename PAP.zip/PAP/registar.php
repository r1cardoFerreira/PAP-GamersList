<!DOCTYPE html>
<html>
</head>
<script src="sweetalert2.all.min.js"></script>
</head>
<body>
<?php
$nome = $_POST['nome'];
$password = $_POST['password'];
$email = $_POST['email'];
$confirmpass = $_POST['confirmar'];

$connect = mysqli_connect('localhost','ricardo','123','gamerslist');

$query_select = "SELECT nome_utilizador FROM utilizador WHERE nome_utilizador = '$nome'";
$select = mysqli_query($connect,$query_select);

$check = mysqli_query($connect,"SELECT * FROM utilizador WHERE nome_utilizador = '$nome'");
if(mysqli_num_rows($check)) {
 echo"<script language='javascript' type='text/javascript'>
          Swal.fire('');window.location
          .href='Registo.php'</script>";
}elseif ($password === $confirmpass){
        $query ="INSERT INTO utilizador (nome_utilizador,palavra_passe,email) VALUES ('$nome','$password','$email')";
        $insert = mysqli_query($connect,$query);

          echo"<script language='javascript' type='text/javascript'>
          alert('Utilizador Registado');window.location.
          href='Login.php'</script>";
        }else {
          echo"<script language='javascript' type='text/javascript'>
          alert('confirmação de palavra passe incorreta');window.location.
          href='Registo.php'</script>";
        }
?>
</body>
</html>
