<footer style="margin-bottom:0px;">
        <div class="footer col-12 col-s-12"><br>
           <center><span style="float:left;"><a href="contacto.php">Contacto</a></span>
            <span style="text-align: center;"><a href="Sobre.html">Sobre</a></span>
            <span style="float:  right;"><a  href="#">Ricardo Ferreira</a></span></center>
            <p></p>
        </div>
</footer>