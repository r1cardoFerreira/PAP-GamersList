<head>
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</head> 
<?php
require_once 'navbar.php';

$nome = $_SESSION['nome'];
$nomevd = ucfirst($nome);
$connect = mysqli_connect('localhost','ricardo','123','gamerslist');
$sql =("SELECT jogos FROM listas WHERE Utilizador ='$nome'");
$result = mysqli_query($connect,$sql);
echo"<div class='col-4 fundo'style='height: 100%;' ></div>";
echo"<div class='col-8'>";
echo" <center><h3 style='font-size:24px;padding-top:50px;color:navy;'>Bem vindo à <img style src='imagens/logotipo.png'> $nomevd</h3></center>";
echo"</div>";
?>
<div>

</div>
<div class="col-8">
<table class='tabela' >
      <tr>
            <th>Jogos</th>
            <th>Remover Da lista</th>
      </tr>
<?php
while ($dados = mysqli_fetch_assoc($result)) {
      
      echo "<tr>";
      echo "<td>".$dados["jogos"]."</td>";
      echo "<td><form action='removerlista.php' method ='post' style='margin:0px'>
        <button class='buttonremove'><i class='fas fa-trash' style='color:red'></i></button>";
      echo "<input type='hidden' value='".$dados['jogos']."'>";
      echo "</from></td>";
      echo "<tr>";
      }
?>
 </div>
    </div>